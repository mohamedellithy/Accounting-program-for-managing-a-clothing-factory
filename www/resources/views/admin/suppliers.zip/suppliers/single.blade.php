@extends('adminlte::page')

@section('title', 'Dashboard')

@section('content_header')
    <h1> تفاصيل التاجر </h1>
@stop


@section('content')
    <!-- Main content -->
    
    <section class="content">
	    <div class="container-fluid">
	        <!-- start row -->
	        <div class="row">
	            <!-- start row orders clothes -->
	            <div class="side-by-side col-md-8"> 
				   <div class="card">
		              <div class="card-header border-transparent">
		                <h3 class="card-title">طلبات القماش الخاصة بالتاجر</h3>
		              </div>
		              <!-- /.card-header -->
		              <div class="card-body p-0">
		                <div class="table-responsive" style="max-height: 300px;">
		                  <table class="table m-0">
		                    <thead>
		                    <tr>
		                      <th>رقم الطلب</th>
		                      <th>الطلبية</th>
		                      <th>الدفع</th>
		                      <th>تاريخ </th>
		                      <th>المبلغ المدفوع</th>
		                      <th>المبلغ المتبقى</th>
		                      <th>تفاصيل </th>
		                    </tr>
		                    </thead>
		                    <tbody>
		                    	@if(!empty($order_clothes_info))
				              	    @foreach($order_clothes_info as $order_clothes)
					                    <tr>
					                      <td><a href="pages/examples/invoice.html"> {{ $order_clothes->id }} </a></td>
					                      <td>{{$order_clothes->category_name->category }}</td>
					                      <td><span class="badge {{ ( ($order_clothes->payment_type=='نقدى')?'badge-success':'badge-info') }} ">{{ $order_clothes->payment_type }}  </span></td>
					                      <td>
					                        <div class="sparkbar" data-color="#00a65a" data-height="20"> {{$order_clothes->created_at }} </div>
					                      </td>
					                       @if($order_clothes->payment_type=='دفعات')
		                                       <td>{{ $order_clothes->postponeds_money->sum('posponed_value')  }} جنيه </td>
		                                       <td>{{ $order_clothes->order_price - $order_clothes->postponeds_money->sum('posponed_value') }} جنيه </td>
                                               @php define('any_postponeds',$order_clothes->order_price - $order_clothes->postponeds_money->sum('posponed_value')) @endphp
                                           @elseif($order_clothes->payment_type=='شيك')
							                   <td>{{ $order_clothes->bank_check->where('payed_check',1)->sum('check_value') + $order_clothes->bank_check->where('payed_check',1)->sum('increase_value') }} جنيه </td>
							                   <td>{{ $order_clothes->order_price - $order_clothes->bank_check->where('payed_check',1)->sum('check_value') }} جنيه </td>
							                   
                                            @else
                                               <td>{{ $order_clothes->order_price }} جنيه</td>
                                               <td>0 جنيه</td> 
                                             @endif

					                      <td >
					                      	  <a href="{{ url('single-order-clothes/'.($order_clothes->order_follow?$order_clothes->order_follow:$order_clothes->id) ) }}" class="btn btn-sm btn-primary float-left">تفاصيل</a>
					                      </td>
					                    </tr>
					                @endforeach
					            @else
					                <tr>
					                	 <td colspan="5" style="text-align:center"> لايوجد اى طلبات </td>
					                </tr>
					            @endif		                   
		                    </tbody>
		                  </table>
		                </div>
		                <!-- /.table-responsive -->
		              </div>
		              <!-- /.card-body -->
		              <div class="card-footer clearfix">
		              <!--   <a href="{{ url('delete-merchant-orders/'.$merchant_id) }}"  class="btn btn-sm btn-info delete_all float-left" data-toggle="modal" data-target="#modal-default"  > <i class="far fa-trash-alt"></i> حذف الطلبات</a> -->
		                <a href="#" class="btn btn-sm btn-info float-left">طباعة</a>                 
		              </div>
		              <!-- /.card-footer -->
		            </div>
                    <!-- --------------------------------------------------------------- -->
		            <!-- --------------------------------------------------------------- -->
		            <!-- --------------------------------------------------------------- -->

		            <div class="card">
		              <div class="card-header border-transparent">
		                <h3 class="card-title">شيكات مطلوب تسديدها</h3>
		              </div>
		              <!-- /.card-header -->
		              <div class="card-body p-0">
		                <div class="table-responsive" style="max-height: 400px;">
		                  <table class="table m-0">
		                    <thead>
		                    <tr>
		                      <th>رقم الشيك</th>
		                      <th>شيك باسم</th>
		                      <th>تاريخ تسديد الشيك</th>
		                      <th>قيمة الشيك </th>
		                      <th>حالة الشيك </th>
		                      <th>مبالغ اضافية </th>
		                      <th>تفاصيل </th>
		                      <th>تسديد الشيك </th>
		                    </tr>
		                    </thead>
		                    <tbody>
		                    	@if(!empty($order_clothes_info_bankCheck))
				              	    @foreach($order_clothes_info_bankCheck as $order_clothes)
				              	        @if(!empty($order_clothes->bank_check))
					              	        @foreach($order_clothes->bank_check as $bank_check)
					              	           @if(($bank_check->payed_check==null) && ($bank_check->bank_checkable_type=='orderClothes') )
								                    <tr>
									                      <td><a href="#"> {{ $bank_check->id }} </a></td>
									                      <td> {{$bank_check->check_owner }} </td>
									                      <td><span class="badge {{ ( ($order_clothes->payment_type=='نقدى')?'badge-success':'badge-info') }} "> {{$bank_check->check_date }} </span></td>
									                      <td>
									                        <div class="sparkbar" data-color="#00a85a" data-height="20"> {{ $bank_check->check_value }} جنيه </div>
									                      </td>
									                      <td>
									                        <div class="sparkbar" data-color="#00a65a" data-height="20"><span class="badge badge-{{ ( ($bank_check->check_date > date('Y-m-d') )?'warning':'danger') }}"> {{ ( ($bank_check->check_date > date('Y-m-d') )?'منتظر':'منأخر') }} </span></div>
									                      </td>
									                      <td >
									                        	{{ ($bank_check->increase_value?$bank_check->increase_value:'0') }} جنيه
									                      </td>
									                      <td >
									                      	  <a href="#" class="btn btn-sm btn-primary float-left">تفاصيل</a>
									                      </td>
									                      <td>
									                      	    @if($bank_check->payed_check==null)
												                    <a href=" {{ url('approve-check/'.$bank_check->id) }}" class="btn btn-success btn-sm"> تسديد </a>                       
												                @else
												                    تم التسديد
												                @endif
									                      </td>
								                    </tr>
							                    @endif
						                    @endforeach
						                @endif
					                @endforeach
					            @else
					                <tr>
					                	 <td colspan="5" style="text-align:center"> لايوجد اى طلبات </td>
					                </tr>
					            @endif		                   
		                    </tbody>
		                  </table>
		                </div>
		                <!-- /.table-responsive -->
		              </div>
		              <!-- /.card-body -->
		              <div class="card-footer clearfix">
		                <a href="#" class="btn btn-sm btn-info float-left">طباعة</a>
		                
		              </div>
		              <!-- /.card-footer -->
		            </div>
		             <!-- --------------------------------------------------------------- -->
		             <!-- --------------------------------------------------------------- -->
		             <!-- --------------------------------------------------------------- -->
		             <!-- --------------------------------------------------------------- -->
		             <!-- --------------------------------------------------------------- -->

		            <div class="card">
		              <div class="card-header border-transparent" style="background-color:#CDDC39;" >
		                <h3 class="card-title">شيكات تم تسديدها</h3>
		              </div>
			              <!-- /.card-header -->
			              <div class="card-body p-0">
			                <div class="table-responsive" style="max-height: 400px;">
			                  <table class="table m-0">
			                    <thead>
			                    <tr>
			                      <th>رقم الشيك</th>
			                      <th>شيك باسم</th>
			                      <th>تاريخ تسديد الشيك</th>
			                      <th>قيمة الشيك </th>
			                      <th>حالة الشيك </th>
			                      <th>مبالغ اضافية </th>
			                      <th>تفاصيل </th>
			                    </tr>
			                    </thead>
			                    <tbody>
			                    	@if(!empty($order_clothes_info_bankCheck))
					              	    @foreach($order_clothes_info_bankCheck as $order_clothes)
					              	        @if(!empty($order_clothes->bank_check))
						              	        @foreach($order_clothes->bank_check as $bank_check)
						              	           @if(($bank_check->payed_check!=null) && ($bank_check->bank_checkable_type=='orderClothes') )
									                    <tr>
										                      <td><a href="#"> {{ $bank_check->id }} </a></td>
										                      <td> {{$bank_check->check_owner }} </td>
										                      <td><span class="badge {{ ( ($order_clothes->payment_type=='نقدى')?'badge-success':'badge-info') }} "> {{$bank_check->check_date }} </span></td>
										                      <td>
										                        <div class="sparkbar" data-color="#00a85a" data-height="20"> {{ $bank_check->check_value }} جنيه </div>
										                      </td>
										                      <td>
										                        <div class="sparkbar" data-color="#00a65a" data-height="20"><span class="badge badge-success "> تم تسديد </span></div>
										                      </td>
										                      <td >
										                        	{{ ($bank_check->increase_value?$bank_check->increase_value:'0') }} جنيه
										                      </td>
										                      <td >
										                      	  <a href="#" class="btn btn-sm btn-primary float-left">تفاصيل</a>
										                      </td>
									                    </tr>
								                    @endif
							                    @endforeach
							                @endif
						                @endforeach
						            @else
						                <tr>
						                	 <td colspan="5" style="text-align:center"> لايوجد اى طلبات </td>
						                </tr>
						            @endif		                   
			                    </tbody>
			                  </table>
			                </div>
			                <!-- /.table-responsive -->
			              </div>
		              <!-- /.card-body -->
		              <div class="card-footer clearfix">
		                <a href="#" class="btn btn-sm btn-info float-left">طباعة</a>
		                
		              </div>
		              <!-- /.card-footer -->
		            </div>
		            <!-- --------------------------------------------------------------- -->
		            <!-- --------------------------------------------------------------- -->
		            <!-- --------------------------------------------------------------- -->
		            <!-- --------------------------------------------------------------- -->
		            <!-- --------------------------------------------------------------- -->
		            
		            <div class="card">
		              <div class="card-header border-transparent">
		                <h3 class="card-title">الدفعات الخاصة بالتاجر</h3>
		              </div>
		              <!-- /.card-header -->
		              <div class="card-body p-0">
		                <div class="table-responsive" style="max-height: 400px;">
		                  <table class="table m-0">
		                    <thead>
		                    <tr>
		                      <th>رقم الدفعة</th>
		                      <th>قيمة الدفعة</th>
		                      <th>تاريخ تسديد الدفعة</th>
		                      <th>الطلبية </th>
		                    </tr>
		                    </thead>
		                    <tbody>
		                    	@if(!empty(get_orderClothes($merchant_id)))
		                    	    @foreach(get_orderClothes($merchant_id) as $postponed_data)
		                    	        @if(!empty($postponed_data))
		                    	            @foreach($postponed_data->postponeds_money as $postponed_data)
			          						    <tr>
								                      <td><a href="#"> {{ $postponed_data->id }} </a></td>
								                      <td> {{$postponed_data->posponed_value }} جنيه </td>
								                      <td><span class="badge badge-info"> {{ $postponed_data->created_at }} </span></td>
								                      <td>
								                        <div class="sparkbar" data-color="#00a85a" data-height="20"> {{ $postponed_data->orderClothes->category_name->category }} </div>
								                      </td>
								                     
							                    </tr>
							                @endforeach
							            @endif
							        @endforeach
					            @else
					                <tr>
					                	 <td colspan="5" style="text-align:center"> لايوجد اى طلبات </td>
					                </tr>
					            @endif		                   
		                    </tbody>
		                  </table>
		                </div>
		                <!-- /.table-responsive -->
		              </div>
		              <!-- /.card-body -->
		              <div class="card-footer clearfix">
		                <a href="#" class="btn btn-sm btn-info float-left">طباعة</a>
		                
		              </div>
		              <!-- /.card-footer -->
		            </div>

		              <!-- --------------------------------------------------------------- -->
		            <!-- --------------------------------------------------------------- -->
		            <!-- --------------------------------------------------------------- -->
		            <!-- --------------------------------------------------------------- -->
		            <!-- --------------------------------------------------------------- -->
		            
		            <div class="card">
		              <div class="card-header border-transparent">
		                <h3 class="card-title">تسديد دفعة</h3>
		              </div>
		              <form method="POST" action="{{ url('merchant/add-postponed/'.$merchant_id) }}">
		              	  {{ csrf_field() }}
			              <!-- /.card-header -->
			              <div class="card-body p-0">
			                <div class="table-responsive" style="max-height: 400px;">
		                    	@if(!empty(get_orderClothes($merchant_id)))
		                    	    @foreach(get_orderClothes($merchant_id) as $postponed_data)
		                    	        @if(!empty($postponed_data))
		                    	           
			          						   <div class="form-group col-12">
							                      <!-- text input -->
							                      <div class="form-group">
							                        <label>تسديد دفعة من المبلغ</label>
	                                                @if(any_postponeds != 0):
	                                                   المبلغ المتبقى للتاجر : {{ any_postponeds }} جنيه
							                           <input name="postponed_value" type="text" class="form-control" placeholder="المبلغ المطلوب تسديدة ..." required="">
							                        @endif
							                      </div>
						                        </div>
							                
							            @endif
							        @endforeach
					            @endif
			                </div>
			                <!-- /.table-responsive -->
			              </div>
			              <!-- /.card-body -->
			              <div class="card-footer clearfix">
			                <button  class="btn btn-sm btn-primary float-left">تسديد دفعة</button>
			                
			              </div>
			              <!-- /.card-footer -->
		              </form>
		            </div>

	            </div>
	            <!-- start orders clothes -->

	            <!-- start row orders clothes -->
	            <div class="side-by-side col-md-4"> 
		            <!-- general form elements -->
				    <div class="card">
		              <div class="card-header" style="background-color:rgb(253 233 62);">
		                <h3 class="card-title">تفاضيل التاجر</h3>
		              </div>
		              @if(!empty($merchant_data))
		              	 @foreach($merchant_data as $merchant_info)
			              <!-- /.card-header -->
			              <div class="card-body p-0">
			                <ul class="products-list product-list-in-card pl-2 pr-2">
			              
				                  <!-- /.item -->
				                  <li class="item">
				                    <div class="product-info">
				                      <a href="javascript:void(0)" class="product-title">اسم التاجر </a>
				                      <span class="product-description">
				                        {{ $merchant_info->merchant_name }}
				                      </span>
				                    </div>
				                  </li>

				                  <!-- /.item -->
				                  <li class="item">
				                    <div class="product-info">
				                      <a href="javascript:void(0)" class="product-title">رقم الجوال</a>
				                      <span class="product-description">
				                         {{ $merchant_info->merchant_phone }}
				                      </span>
				                    </div>
				                  </li>

				                  <!-- /.item -->
				                  <li class="item">
				                    <div class="product-info">
				                      <a href="javascript:void(0)" class="product-title">عدد الطلبات</a>
				                      <span class="product-description">
				                         {{ $merchant_info->order_clothes->count() }}
				                      </span>
				                    </div>
				                  </li>

				               
			                </ul>
			              </div>
			              <!-- /.card-body -->
			              <div class="card-footer text-center">
				               <a href="tel: {{ $merchant_info->merchant_phone }}">  <i class="fab fa-whatsapp-square fa-2x" style="color:#3fad3f"></i></a>
	                           <a href="tel: {{ $merchant_info->merchant_phone }}"> <i class="fas fa-lg fa-phone fa-2x" style="color:#007bff"></i></a>
			              </div>
			              <!-- /.card-footer -->
			            @endforeach
			        @endif
		            </div>
			            </div>
			        </div>
			        <!-- end row -->

			    </div>
    </section>



      <div class="modal fade show" id="modal-default"  aria-modal="true">
        <div class="modal-dialog">
          <div class="modal-content">
            <div class="modal-header">
              <h4 class="modal-title">تأكيد حذف تاجر</h4>
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">×</span>
              </button>
            </div>
            <div class="modal-body">
              <p>تأكيد حذف المحدد من جدول التجار</p>
            </div>
            <div class="modal-footer justify-content-between">
              
              <a type="button" href="#" class="btn btn-primary " id="confirm_delete" >تأكيد الحذف</a>
            </div>
          </div>
          <!-- /.modal-content -->
        </div>
        <!-- /.modal-dialog -->
      </div>
@stop

@section('css')
    <!-- Bootstrap 4 RTL -->
     <link rel="stylesheet" href="{{  asset('vendor/adminlte/dist/css/bootstrap-rtl.css') }}">
    <link rel="stylesheet" href="{{ asset('vendor/adminlte/dist/css/custom.css') }}">
@stop

@section('js')
  <script type="text/javascript">
      var typeAlert = "";
      $('body').on('click','.delete_all',function(event){
          typeAlert = jQuery(this).attr('href');
          event.preventDefault();
      });
      $('#confirm_delete').click(function(){
        if(!typeAlert){
          $('form#form_delete_select').submit();        
        }
        else
        {
          window.location.href=typeAlert;
        }
      });
  </script>
@stop