

<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1> تعديل المرتجع </h1>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
      <!-- Main content -->
    
    <section class="content">
	    <div class="container-fluid">
	        <div class="row">
	            <!-- left column -->
	            <div class="col-md-12"> 
	            	<?php if($message = Session::get('success')): ?>
		            	<div class="alert alert-warning alert-dismissible">
		                  <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
		                  <h5><i class="icon fas fa-check"></i> تمت</h5>
		                  <?php echo e($message); ?>

		                </div>
		            <?php endif; ?>
		             <div class="" style="text-align: left !important;">
		                 <a href="<?php echo e(url('show-orders')); ?>" class="btn btn-info"> الرجوع </a>
		            </div>
		            <!-- general form elements -->
		            <div class="card card-primary">
		              <div class="card-header">
		                <h3 class="card-title">تعديل المرتجع</h3>
		              </div>
		              <!-- /.card-header -->
		              <?php $__currentLoopData = $order_product_info; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order_info): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		              <!-- form start -->
		              <form action="<?php echo e(url('update-reactionist/'.$order_info->id.'/'.$order_info->order_id)); ?>" role="form" method="POST">
                        <?php echo e(csrf_field()); ?>

		                <div class="card-body">
		                 
                            <!-- merchant name  -->		                    
		                   <div class="form-group col-6 col-xs-12">
			                  <label for="exampleInputEmail1">اسم المنتج</label>
			                  <select name="product_id" class="form-control select2" style="width: 100%;" required>
			                   <?php if(!empty($get_all_products)): ?>
			                       <?php $__currentLoopData = $get_all_products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			                           <option value="<?php echo e($product->id); ?>" <?php echo e((($order_info->product_id==$product->id)?'selected':'')); ?> > <?php echo e($order_info->product_name->name_product); ?> </option>
			                       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			                   <?php endif; ?>
			                  </select>
			                </div>

		                  <!-- merchant name  -->		                    
		                   <div class="form-group col-6 col-xs-12">
			                  <label for="exampleInputEmail1">اسم العميل </label>
			                  <select name="client_id" class="form-control select2" style="width: 100%;" >
			                    <option value="">بدون</option>
			                   <?php if(!empty($all_clients)): ?>
			                       <?php $__currentLoopData = $all_clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			                           <option value="<?php echo e($client->id); ?>" <?php echo e((($order_info->client_id==$client->id)?'selected':'')); ?> > <?php echo e(($order_info->client_id?$order_info->client_name->client_name:'')); ?> </option>
			                       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			                   <?php endif; ?>
			                  </select>
			                </div>

			               <!-- order Category  -->
		                   <div class="form-group col-6 col-xs-12">
			                   <label for="exampleInputPassword1">الصنف</label>
			                  <select name="category_id" class="form-control select2" style="width: 100%;">
			                   
			                   <?php if(!empty($get_all_categories)): ?>
			                       <?php $__currentLoopData = $get_all_categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			                           <option value="<?php echo e($category->id); ?>" <?php echo e((($order_info->product_name->category_id==$category->id)?'selected':'')); ?> > <?php echo e($order_info->product_name->category_name->category); ?> </option>
			                       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			                   <?php endif; ?>
			                 
			                  </select>
			                </div>
		                  
		                  <!-- order value  -->
		                  <div class="form-group col-6 col-xs-12">
		                    <label for="exampleInputPassword1">كمية الطلبية</label>
		                    <input name="order_count" value=" <?php echo e($order_info->order_count); ?> " type="text" class="form-control" id="exampleInputPassword1" placeholder="كمية الطلبية" required>
		                      <input name="old_order_count" value=" <?php echo e($order_info->order_count); ?> " type="text" class="form-control" id="exampleInputPassword1" placeholder="كمية الطلبية" hidden>
		                  </div>

		                  <!-- order price  -->
		                  <div class="form-group col-6 col-xs-12">
		                    <label for="exampleInputPassword1">سعر القطعة الواحدة</label>
		                    <input name="reactionist_price" value=" <?php echo e($order_info->reactionist_price); ?> " type="text" class="form-control" id="exampleInputPassword1" placeholder="سعر الطلبية بالجنية" required>
		                  </div>

		                  <!-- order type payment  -->
		                  <div class="form-group col-6 col-xs-12">
		                    <label for="exampleInputPassword1">نوع الدفع</label>
			                  <select name="payment_type" class="form-control select2" style="width: 100%;" required>
			                        <option value="نقدى" <?php echo e((($order_info->payment_type=='نقدى')?'selected':'')); ?> > نقدى </option>
			                        <option value="شيك" <?php echo e((($order_info->payment_type=='شيك')?'selected':'')); ?> > شيك </option>
			                 
			                  </select>
			              </div>
		                  
		                </div>
		                <!-- /.card-body -->

		                <div class="card-footer">
		                  <button type="submit" class="btn btn-primary"> تعديل الطلبية </button>
		                </div>
		              </form>
		              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		            </div>
		            <!-- /.card -->
	            </div>
	        </div>
	    </div>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
     <link rel="stylesheet" href="<?php echo e(asset('vendor/adminlte/plugins/plugins/select2/css/select2.min.css')); ?>">
     <link rel="stylesheet" href="<?php echo e(asset('vendor/adminlte/plugins/plugins/select2-bootstrap4-theme/select2-bootstrap4.min.css')); ?>">

    <!-- Bootstrap 4 RTL -->
     <link rel="stylesheet" href="<?php echo e(asset('vendor/adminlte/dist/css/bootstrap-rtl.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('vendor/adminlte/dist/css/custom.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script src="<?php echo e(asset('vendor/adminlte/plugins/plugins/select2/js/select2.full.min.js')); ?>"></script>
    <script>
		  $(function () {
		    //Initialize Select2 Elements
		    $('.select2').select2({
		      theme: 'bootstrap4'
		    });
		});
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp\www\mohamed-Reda\clothes\resources\views/admin/reactionist/edite.blade.php ENDPATH**/ ?>