

<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1> مراجعة فاتورة البيع </h1>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
    <!-- Main content -->
    
    <section class="content">
	    <div class="container-fluid">
	        <div class="row">
	            <!-- left column -->
	            <div class="col-md-12"> 
	            	<?php if($message = Session::get('success')): ?>
		            	<div class="alert alert-warning alert-dismissible">
		                  <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
		                  <h5><i class="icon fas fa-check"></i> تمت</h5>
		                  <?php echo e($message); ?>

		                </div>
		            <?php endif; ?>
		            <!-- general form elements -->
		            <div class="card card-primary">
		              <div class="card-header">
		                <h3 class="card-title">مراجعة فاتورة البيع</h3>
		              </div>
		              <div class="col-12">
		                 <br/>
		                  <a class="btn btn-warning printDiv" style="width: 18%;"> طباعة الفاتورة </a>
		                  <a href="<?php echo e(url('show-orders')); ?>" class="btn btn-info" style="width: 18%;color:white"> الرجوع الى الطلبات </a>
		              </div>
		                <div class="card-body cardbody merchantsContainer" id="merchantsContainer">
		                    <div class="col-xs-12">
		                    	<div class="col-xs-12 text-right" style="padding:10px;text-align: right !important;font-size:20px;font-weight:600">
                                   <span> تحرير فى : <?php echo e(date('Y').'/'.date('m').'/'.date('d')); ?></span>                                    
		                    	</div>
		                    	<div class="col-xs-12 text-right" style="padding:10px;text-align: right !important;font-size:20px;font-weight:200">
                                   <span> مطلوب من السيد : 
                                   	    <?php if(!empty($last_order_review)): ?>
                                           <?php $__currentLoopData = $last_order_review; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                               <?php echo e(($order->client_name?$order->client_name->client_name:'')); ?>

                                               <?php break ?>
                                           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>
                                   	
                                   </span>                                    
		                    	</div>
		                    	<table class="table table-bordered">
		                    		<thead>
			                    		<tr>
			                    			<th colspan="2">اجمالى السعر</th>
			                    			<th colspan="2">سعر الوحدة</th>
			                    			<th rowspan="2">العدد</th>
			                    			<th rowspan="2">تخفيض</th>
			                    			<th>الصنف</th>
			                    		</tr>
			                    		<tr>
			                    			<th>قرش</th>
			                    			<th>جنيه</th>
			                    			<th>قرش</th>
			                    			<th>جنيه</th>
			                    			
			                    		
			                    			<th></th>
			                    		</tr>
			                    	</thead>
			                    	<tbody>
			                    	   <?php $all_cost=0 ?>
			                    	   <?php $order_discount = 0 ?> 
                                       <?php if(!empty($last_order_review)): ?>
                                           <?php $__currentLoopData = $last_order_review; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                           <?php $all_cost +=$order->final_cost  ?>
                                              <tr>
                                              	  <td><?php echo e(round($order->final_cost - intval($order->final_cost),2)); ?></td>
                                              	  <td><?php echo e(intval($order->final_cost)); ?></td>
                                              	  <td><?php echo e(round((($order->order_price / $order->order_count) + $order->order_taxs) - floor(($order->order_price / $order->order_count) + $order->order_taxs),2)); ?></td>
                                              	  <td><?php echo e(floor(($order->order_price / $order->order_count) + $order->order_taxs)); ?></td>
                                              	  <td><?php echo e(intval($order->order_count)); ?></td>
                                              	  <td><?php echo e(intval($order->order_discount)); ?></td>
                                              	     <?php $order_discount += $order->order_discount ?> 
                                              	  <td><?php echo e($order->product_name->category_name->category); ?></td>
                                              </tr>
                                           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                           <tr>
                                           	  <td colspan="7"> التكلفة الكلية : <?php echo e(($all_cost?$all_cost:'0') - $order_discount); ?> جنيه </td>
                                           </tr>
                                       <?php endif; ?>
			                    	</tbody>
		                    	</table>
				            </div>
				        </div>
				    </div>
				    <!-- /.card -->
	            </div>
	        </div>
	    </div>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <!-- Bootstrap 4 RTL -->
     <link rel="stylesheet" href="<?php echo e(asset('vendor/adminlte/plugins/plugins/select2/css/select2.min.css')); ?>">
     <link rel="stylesheet" href="<?php echo e(asset('vendor/adminlte/plugins/plugins/select2-bootstrap4-theme/select2-bootstrap4.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('vendor/adminlte/dist/css/bootstrap-rtl.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('vendor/adminlte/dist/css/custom.css')); ?>">
     <style type="text/css">
      @media  print {
        table th , table td 
        {
          display:  table-cell !important;
        } 
      }
    </style> 

<?php $__env->stopSection(); ?>
<!-- Select2 -->
<?php $__env->startSection('js'); ?>
	<script src="<?php echo e(asset('vendor/adminlte/plugins/plugins/select2/js/select2.full.min.js')); ?>"></script>

      <script >
        jQuery('body').on('click','.printDiv',function(event){

            event.preventDefault();

            var printContents = document.getElementById("merchantsContainer").innerHTML;
                              
             var originalContents = document.body.innerHTML;
             
             document.body.innerHTML = printContents;
             
             window.print();
             
             document.body.innerHTML = originalContents;
            // window.location.reload();
        });
            
        
    </script>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp\www\mohamed-Reda\clothes\resources\views/admin/orders/review.blade.php ENDPATH**/ ?>