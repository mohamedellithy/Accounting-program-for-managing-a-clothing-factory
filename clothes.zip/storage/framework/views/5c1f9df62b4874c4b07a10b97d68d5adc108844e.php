

<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1> اضافة تصنيف </h1>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
    <!-- Main content -->
    
    <section class="content">
	    <div class="container-fluid">
	        <div class="row">
	            <!-- left column -->
	            <div class="col-md-12"> 
	            	<?php if($message = Session::get('success')): ?>
		            	<div class="alert alert-warning alert-dismissible">
		                  <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
		                  <h5><i class="icon fas fa-check"></i> تمت</h5>
		                  <?php echo e($message); ?>

		                </div>
		            <?php endif; ?>
		            <!-- general form elements -->
		            <div class="card card-primary">
		              <div class="card-header">
		                <h3 class="card-title">اضافة الصنف قماش جديد</h3>
		              </div>
		              <!-- /.card-header -->
		              <!-- form start -->
		              <form action="<?php echo e(url('create-category')); ?>" role="form" method="POST">
                        <?php echo e(csrf_field()); ?>

		                <div class="card-body">
		                  <div class="form-group">
		                    <label for="exampleInputEmail1">اسم الصنف</label>
		                    <input name="category" type="name" class="form-control" id="exampleInputEmail1" placeholder="اسم التصنيف">
		                  </div>
		               
		              
		                </div>
		                <!-- /.card-body -->

		                <div class="card-footer">
		                  <button type="submit" class="btn btn-primary"> اضافة صنف </button>
		                </div>
		              </form>
		            </div>
		            <!-- /.card -->

		            
				    <div class="card">
				      <div class="card-header">
				        <h3 class="card-title">أخر ما تم اضافته من صنف</h3>
				      </div>
				      <!-- /.card-header -->
				      <div class="card-body">
				        <table class="table table-bordered">
				          <thead>                  
				            <tr>
				              <th>#</th>
				              <th>أسم الصنف</th>
				              <th>تاريخ الاضافة</th>
				            </tr>
				          </thead>
				          <tbody>
				          	<?php if($last = (Session::get('last_category')?Session::get('last_category'):$last_category) ): ?> 
					              <tr>
						              <td>1.</td>
						              <td> <?php echo e($last->category); ?> </td>
						              <td>
						                  <?php echo e($last->created_at); ?>

						              </td>
						             
					               </tr>
					        <?php endif; ?>
				         
				          </tbody>
				        </table>
				      </div>
				    
				    </div>
				    <!-- /.card -->
	            </div>
	        </div>
	    </div>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <!-- Bootstrap 4 RTL -->
     <link rel="stylesheet" href="<?php echo e(asset('vendor/adminlte/dist/css/bootstrap-rtl.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('vendor/adminlte/dist/css/custom.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp\www\mohamed-Reda\clothes\resources\views/admin/category/create.blade.php ENDPATH**/ ?>