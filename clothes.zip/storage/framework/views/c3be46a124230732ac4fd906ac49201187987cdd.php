

<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1> اضافة دائن و مدين </h1>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
    <!-- Main content -->
    
    <section class="content">
      <div class="container-fluid">
          <div class="row">
              <!-- left column -->
              <div class="col-md-12"> 
                <?php if($message = Session::get('success')): ?>
                  <div class="alert alert-warning alert-dismissible">
                      <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                      <h5><i class="icon fas fa-check"></i> تمت</h5>
                      <?php echo e($message); ?>

                    </div>
                <?php endif; ?>
                <!-- general form elements -->
                <div class="card card-primary">
                  <div class="card-header">
                    <h3 class="card-title">اضافة دائن و مدين</h3>
                  </div>
                  <!-- /.card-header -->
                  <!-- form start -->
                  <form action="<?php echo e(url('create-debit')); ?>" role="form" method="POST">
                        <?php echo e(csrf_field()); ?>

                    <div class="card-body">
                      <div class="form-group">
                        <label for="exampleInputEmail1">القسم</label>
                        <select name="debitable_type" id="section-type" class="form-control select2"  placeholder="القسم" >
                             <option value="">أخر</option>
                             <option value="merchant">تجار</option>
                             <option value="client">عملاء</option>
                             <option value="suppliers">مصنع</option>
                        </select>
                      </div>

                      <div class="form-group">
                        <label for="exampleInputEmail1">نوع المديونية</label>
                         <select name="debit_type"  class="form-control select2"  placeholder="القسم" required>
                             <option value="دائن">دائن</option>
                             <option value="مدين">مدين</option>
                             
                        </select>
                      </div>

                       <div class="form-group">
                        <label for="exampleInputEmail1">نوع دفع المديونية</label>
                         <select name="type_payment"  class="form-control select2"  placeholder="القسم" required>
                             <option value="نقدى">نقدى</option>
                             <option value="دفعات">دفعات</option>
                             <option value="شيكات">شيكات</option>
                        </select>
                      </div>

                      <div class="form-group" id="merchant_name" style="display:none">
                        <label for="exampleInputEmail1">اسم التجار</label>
                        <select name="debitable_id"   class="form-control select2"  placeholder="القسم" style="" disabled>
                           
                          <?php if(!empty($all_merchants)): ?>
                               <?php $__currentLoopData = $all_merchants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $merchant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                   <option value="<?php echo e($merchant->id); ?>"> <?php echo e($merchant->merchant_name); ?> </option>
                               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                           <?php endif; ?>
                        </select>
                      </div>

                      <div class="form-group" id="client_name" style="display:none">
                        <label for="exampleInputEmail1">اسم العميل</label>
                        <select name="debitable_id"   class="form-control select2"  placeholder="القسم" style="display:none" disabled>
                            
                        <?php if(!empty($all_clients)): ?>
                             <?php $__currentLoopData = $all_clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                 <option value="<?php echo e($client->id); ?>"> <?php echo e($client->client_name); ?> </option>
                             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                         <?php endif; ?>
                        </select>
                      </div>

                       <div class="form-group" id="supplier_name" style="display:none">
                        <label for="exampleInputEmail1">اسم المصنع</label>
                        <select name="debitable_id"  class="form-control select2"  placeholder="القسم"  disabled>
                          
                         <?php if(!empty($all_suppliers)): ?>
                             <?php $__currentLoopData = $all_suppliers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $suppliers): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                 <option value="<?php echo e($suppliers->id); ?>"> <?php echo e($suppliers->supplier_name); ?> </option>
                             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                         <?php endif; ?>
                        </select>
                      </div>

                      <div class="form-group" id="debit_name">
                        <label for="exampleInputPassword1">اسم الدائن / المدين</label>
                        <input name="debit_name"  type="phone" class="form-control" id="exampleInputPassword1" placeholder="اسم الدائن / المدين" >
                      </div>

                      <div class="form-group">
                        <label for="exampleInputPassword1">قيمة المبلغ</label>
                        <input name="debit_value" type="debit_value" class="form-control" id="exampleInputPassword1" placeholder="قيمة المبلغ" required>
                      </div>
                  
                    </div>
                    <!-- /.card-body -->

                    <div class="card-footer">
                      <button type="submit" class="btn btn-primary"> اضافة دائن و مدين </button>
                    </div>
                  </form>
                </div>
                <!-- /.card -->

                
            <div class="card">
              <div class="card-header">
                <h3 class="card-title">أخر ما تم اضافته من التجار</h3>
              </div>
              <!-- /.card-header -->
              <div class="card-body">
                <table class="table table-bordered">
                  <thead>                  
                    <tr>
                      <th>#</th>
                      <th>أسم الدائن / المدين</th>
                      <th>نوع الدين</th>
                      <th>قيمة المبلغ</th>
                      <th>تاريخ الانشاء</th>                      
                    </tr>
                  </thead>
                  <tbody>
                    <?php if($last = (Session::get('last_debit')?Session::get('last_debit'):$last_debit) ): ?> 
                        <tr>
                          <td>1.</td>
                          <td>
                           <?php if(($last->debitable_type!=null)&&($last->debitable_id!=null)): ?>
                             <?php echo e(get_debit_name($last->debitable_type,$last->debitable_id)); ?> 
                           <?php else: ?>
                               <?php echo e($last->debit_name); ?>

                           <?php endif; ?> 

                           </td>
                          <td>
                              <?php echo e($last->debit_type); ?>

                          </td>
                          <td>
                              <?php echo e($last->debit_value); ?> جنيه
                          </td>
                          
                          <td>
                              <?php echo e($last->created_at); ?>

                          </td>
                         
                         </tr>
                  <?php endif; ?>
                 
                  </tbody>
                </table>
              </div>
            
            </div>
            <!-- /.card -->
              </div>
          </div>
      </div>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
     <link rel="stylesheet" href="<?php echo e(asset('vendor/adminlte/plugins/plugins/select2/css/select2.min.css')); ?>">
     <link rel="stylesheet" href="<?php echo e(asset('vendor/adminlte/plugins/plugins/select2-bootstrap4-theme/select2-bootstrap4.min.css')); ?>">

    <!-- Bootstrap 4 RTL -->
     <link rel="stylesheet" href="<?php echo e(asset('vendor/adminlte/dist/css/bootstrap-rtl.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('vendor/adminlte/dist/css/custom.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
  <script src="<?php echo e(asset('vendor/adminlte/plugins/plugins/select2/js/select2.full.min.js')); ?>"></script>
  <script type="text/javascript">
         $('.select2').select2({
          theme: 'bootstrap4'
        });

         $('.select3').select2({
          theme: 'bootstrap4'
        });
  </script>
  <script type="text/javascript">
  jQuery('#section-type').change(function(){
     var type_section = jQuery(this).val();
     console.log(type_section);
     if(type_section=="merchant"){
        jQuery('#merchant_name').show(function(){
            jQuery('#merchant_name select').attr('disabled',false);
        });
        jQuery('#supplier_name').hide(function(){
            jQuery('#supplier_name select').attr('disabled',true);
        });
        jQuery('#client_name').hide(function(){
            jQuery('#client_name select').attr('disabled',true);
        });
        jQuery('#debit_name').hide();
     }
     else if(type_section=='client'){
        jQuery('#merchant_name').hide(function(){
              jQuery('#merchant_name select').attr('disabled',true);
        });
        jQuery('#supplier_name').hide(function(){
              jQuery('#supplier_name select').attr('disabled',true);
        });
        jQuery('#client_name').show(function(){
              jQuery('#client_name select').attr('disabled',false);
        });
        jQuery('#debit_name').hide();
     }
     else if(type_section==''){
        jQuery('#merchant_name').hide(function(){
             jQuery('#merchant_name select').attr('disabled',true);
        });
        jQuery('#supplier_name').hide(function(){
             jQuery('#supplier_name select').attr('disabled',true);
        });
        jQuery('#client_name').hide(function(){
             jQuery('#client_name select').attr('disabled',true);
        });
        jQuery('#debit_name').show();
     }
     else if(type_section=='suppliers'){
        jQuery('#merchant_name').hide(function(){
             jQuery('#merchant_name select').attr('disabled',true);
        });
        jQuery('#supplier_name').show(function(){
             jQuery('#supplier_name select').attr('disabled',false);
        });
        jQuery('#client_name').hide(function(){
             jQuery('#client_name select').attr('disabled',true);
        });
        jQuery('#debit_name').hide();  
     }
  });
  </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp\www\mohamed-Reda\clothes\resources\views/admin/debit/create.blade.php ENDPATH**/ ?>