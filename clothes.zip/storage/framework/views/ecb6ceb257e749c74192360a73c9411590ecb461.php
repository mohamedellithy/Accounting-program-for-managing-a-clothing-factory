

<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1> اضافة مرتجع نقدى </h1>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
    <!-- Main content -->
    
    <section class="content">
	    <div class="container-fluid">
	        <div class="row">
	            <!-- left column -->
	            <div class="col-md-12"> 
	            	<?php if($message = Session::get('success')): ?>
		            	<div class="alert alert-warning alert-dismissible">
		                  <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
		                  <h5><i class="icon fas fa-check"></i> تمت</h5>
		                  <?php echo e($message); ?>

		                </div>
		            <?php endif; ?>
		            <!-- general form elements -->
		            <div class="card card-primary">
		              <div class="card-header">
		                <h3 class="card-title">اضافة مرتجع نقدى</h3>
		              </div>
		              <!-- /.card-header -->
		              <!-- form start -->
		              <form action="<?php echo e(url('create-reactionist/'.$order_id)); ?>" role="form" method="POST">
                        <?php echo e(csrf_field()); ?>

			             <div class="card-body">
			                <?php if(!empty($get_order_info)): ?>
			                    <?php $__currentLoopData = $get_order_info; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order_info): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			                        <!-- order Nimber  -->
				                  <div class="form-group col-md-12 col-xs-12">
				                    <label for="exampleInputPassword1">رقم الطلب</label>
				                    <input name="order_id" value="<?php echo e($order_info->id); ?>" type="text" class="form-control" id="exampleInputPassword1" placeholder="سعر القطعة" required hidden>
				                    <input name="" value="<?php echo e(($order_info->order_follow?$order_info->order_follow:$order_info->id)); ?>" type="text" class="form-control" id="exampleInputPassword1" placeholder="سعر القطعة" required readonly>
				                  </div>

		                           <!-- order Category  -->
				                   <div class="form-group col-md-12 col-xs-12">
					                   <label for="exampleInputPassword1">الصنف</label>
					                   <input name="category_id" value="<?php echo e($order_info->product_name->category_name->id); ?>" hidden>
					                  <select name="category" class="form-control select2" style="width: 100%;" required disabled>
					                   <option > بدون تحديد </option>
					                   <?php if(!empty($get_all_categories)): ?>
					                       <?php $__currentLoopData = $get_all_categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					                           <option value="<?php echo e($category->id); ?>" <?php echo e((($order_info->product_name->category_name->id==$category->id)?'selected':'')); ?> > <?php echo e($category->category); ?> </option>
					                       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					                   <?php endif; ?>
					                 
					                  </select>
					                </div>

					              <!-- product name  -->		                    
				                   <div class="form-group col-md-12 col-xs-12">
					                  <label for="exampleInputEmail1">اسم المنتج</label>
					                  <input name="product_id" value="<?php echo e($order_info->product_name->id); ?>" hidden>
					                  <select name="product" class="form-control select2" style="width: 100%;" required disabled>
					                   <?php if(!empty($all_products)): ?>
					                       <?php $__currentLoopData = $all_products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					                           <option value="<?php echo e($product->id); ?>" <?php echo e((($order_info->product_name->id==$product->id)?'selected':'')); ?> > <?php echo e($product->name_product); ?> </option>
					                       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					                   <?php endif; ?>
					                  </select>
					                </div>

					               

					                <!-- merchant name  -->		                    
				                   <div class="form-group col-md-12 col-xs-12">
					                  <label for="exampleInputEmail1">اسم الزبون</label>
					                  <input name="client_id" value="<?php echo e($order_info->client_id); ?>" hidden>
					                  <select name="client" class="form-control select2" style="width: 100%;" disabled>
					                     <option value=""> بدون تحديد </option>
					                   <?php if(!empty($all_clients)): ?>
					                       <?php $__currentLoopData = $all_clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					                           <option value="<?php echo e($client->id); ?>" <?php echo e(( ( !empty($order_info->client_id) ) && ($order_info->client_name->id==$client->id)?'selected':'')); ?>> <?php echo e($client->client_name); ?> </option>
					                       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					                   <?php endif; ?>
					                  </select>
					                </div>

				                 
				                  
				                  <!-- order value  -->
				                  <div class="form-group col-md-12 col-xs-12">
				                    <label for="exampleInputPassword1">كمية الطلبية</label>
				                    <label for="exampleInputPassword1" style="font-size: 12px;float: left;">الكمية المتوفرة : 0</label>
				                    <input name="order_count" type="text" class="form-control" id="exampleInputPassword1" placeholder="كمية الطلبية" required>
				                  </div>

				                  <!-- order price  -->
				                  <div class="form-group col-md-12 col-xs-12">
				                    <label for="exampleInputPassword1">سعر القطعة</label>
				                    <input name="reactionist_price" value="<?php echo e(round( ($order_info->final_cost)/$order_info->order_count,2)); ?>" type="text" class="form-control" id="exampleInputPassword1" placeholder="سعر القطعة" required>
				                  </div>

				                

				               
				                  <!-- order type payment  -->
				                  <div class="form-group col-md-12 col-xs-12">
				                    <label for="exampleInputPassword1">نوع الدفع</label>
				                       <input name="payment_type" value="<?php echo e($order_info->payment_type); ?>" hidden>
					                  <select name="payment" class="form-control select2" style="width: 100%;" required disabled>
					                        <option value="نقدى"  <?php echo e((($order_info->payment_type=='نقدى')?'selected':'')); ?> > نقدى </option>
					                        <option value="شيك"  <?php echo e((($order_info->payment_type=='شيك')?'selected':'')); ?>> شيك </option>
					                        <option value="أجل"   <?php echo e((($order_info->payment_type=='أجل')?'selected':'')); ?>> أجل </option>
					                 
					                  </select>
					              </div>
					            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					        <?php endif; ?>
		                  
		                </div>
		                <!-- /.card-body -->

		                <div class="card-footer">
		                  <button type="submit" class="btn btn-primary"> اضافة مرتجع نقدى </button>
		                </div>
		              </form>
		            </div>
		            <!-- /.card -->

		            
				    <div class="card">
				      <div class="card-header">
				        <h3 class="card-title">أخر مرتجع نقدى</h3>
				      </div>
				      <!-- /.card-header -->
				      <div class="card-body">
				        <table class="table table-bordered">
				          <thead>                  
				            <tr>
				              <th>#</th>
				              <th>أسم المنتج</th>
				              <th>الصنف</th>
				              <th>الكمية</th>
				              <th>سعر القطعة</th>
				              <th>اسم الزبون </th>
				              <th>نوع الدفع</th>
				              <th>تاريخ مرتجع</th>
				              
				            </tr>
				          </thead>
				          <tbody>
                              <?php if(!empty($last_order)): ?>
                                    <tr>
                                      <td>1#</td>
                                      <td> <?php echo e($last_order->product_name->name_product); ?> </td>
                                      <td> <?php echo e($last_order->product_name->category_name->category); ?> </td>
                                      <td> <?php echo e($last_order->order_count); ?> </td>
                                      <td> <?php echo e($last_order->order_price); ?> جنية </td>                                    
                                      <td> <?php echo e(($last_order->client_name?$last_order->client_name->client_name:'بدون')); ?> </td>
                                      <td> <?php echo e($last_order->payment_type); ?> </td>
                                      <td> <?php echo e($last_order->created_at); ?> </td>
                                    </tr>
                              <?php endif; ?>
				          	
				         
				          </tbody>
				        </table>
				      </div>
				    
				    </div>
				    <!-- /.card -->
	            </div>
	        </div>
	    </div>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <!-- Bootstrap 4 RTL -->
     <link rel="stylesheet" href="<?php echo e(asset('vendor/adminlte/plugins/plugins/select2/css/select2.min.css')); ?>">
     <link rel="stylesheet" href="<?php echo e(asset('vendor/adminlte/plugins/plugins/select2-bootstrap4-theme/select2-bootstrap4.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('vendor/adminlte/dist/css/bootstrap-rtl.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('vendor/adminlte/dist/css/custom.css')); ?>">
    

<?php $__env->stopSection(); ?>
<!-- Select2 -->
<?php $__env->startSection('js'); ?>
	<script src="<?php echo e(asset('vendor/adminlte/plugins/plugins/select2/js/select2.full.min.js')); ?>"></script>
    <script>
		  $(function () {
		    //Initialize Select2 Elements
		    $('.select2').select2({
		      theme: 'bootstrap4',
		    });
		});
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp\www\mohamed-Reda\clothes\resources\views/admin/reactionist/create.blade.php ENDPATH**/ ?>