

<?php $__env->startSection('title', 'عرض المنتجات'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1> <?php echo e(($title?$title:'المنتجات')); ?> </h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
  <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <!-- Info boxes -->
        <div class="row">
         
          <!-- /.col -->
      	  <div class="col-12">
             <form id="form_delete_select" action="<?php echo e(url('delete-select-product')); ?>"  method="POST">
	             <?php echo e(csrf_field()); ?>

	        	    <?php if($message = Session::get('success')): ?>
		            	<div class="alert alert-warning alert-dismissible">
		                  <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
		                  <h5><i class="icon fas fa-check"></i> تمت</h5>
		                  <?php echo e($message); ?>

		                </div>
		            <?php endif; ?>
      		          <div class="card">
      		            <div class="card-header">
      		              <h3 class="card-title">عرض المنتجات</h3>
      		            </div>
      		              
      			              <div id="merchantsContainer" class="card-body">
                            <h2 id="heading_print" style="display:none" > جدول قصات القماش </h2>
                            <table id="merchants" class="table table-bordered table-hover">
                              <thead>
                                <tr>
                                  <th></th>
                                  <th>اسم قصات القماش</th>
                                  <th>الصنف</th>
                                  <th>عدد القطع </th>
                                  <th>التكلفة الكلية</th>
                                  <th>تاريخ الاضافة</th>
                                  <th>اجراءات</th>
                                  <th>عرض</th>
                                </tr>
                              </thead>
                            </table>
                        </div>
      				    </div>
                </form>
      			</div>
            
        </div>
        <!-- /.row -->
      </div>
    </section>

      <div class="modal fade show" id="modal-default"  aria-modal="true">
        <div class="modal-dialog">
          <div class="modal-content">
            <div class="modal-header">
              <h4 class="modal-title">تأكيد حذف المنتجات</h4>
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">×</span>
              </button>
            </div>
            <div class="modal-body">
              <p>تأكيد حذف المحدد من جدول المنتجات</p>
            </div>
            <div class="modal-footer justify-content-between">
              
              <a type="button" href="#" class="btn btn-primary " id="confirm_delete" >تأكيد الحذف</a>
            </div>
          </div>
          <!-- /.modal-content -->
        </div>
        <!-- /.modal-dialog -->
      </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('css'); ?>
    <!-- Bootstrap 4 RTL -->
     <link rel="stylesheet" href="<?php echo e(asset('vendor/adminlte/dist/css/bootstrap-rtl.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('vendor/adminlte/dist/css/custom.css')); ?>">
    <!-- DataTables -->
    <link rel="stylesheet" href="<?php echo e(asset('vendor/adminlte/plugins/plugins/datatables-bs4/css/dataTables.bootstrap4.css')); ?>">
    <style type="text/css">
      @media  print {  
        table th:nth-child(4) , table th:nth-child(5) , table th:nth-child(6) 
        {
          display:  table-cell;
        }
        table td:nth-child(4) , table td:nth-child(5) , table td:nth-child(6) 
        {
          display:  table-cell;
        }

        table th:nth-child(7) , table th:nth-child(8)  
        {
          display: none;
        }
        table td:nth-child(7) , table td:nth-child(8) 
        {
          display: none;
        }
      }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
  <!-- DataTables -->
  <script src="<?php echo e(asset('vendor/adminlte/plugins/plugins/datatables/jquery.dataTables.js')); ?>"></script>
  <script src="<?php echo e(asset('vendor/adminlte/plugins/plugins/datatables-bs4/js/dataTables.bootstrap4.js')); ?>"></script>
    <script> console.log('Hi!'); </script>
    <script>
   jQuery(document).ready( function () {
          jQuery('#merchants').DataTable({
             processing: true,
             serverSide: true,
             ajax: "<?php echo e(url('datatable-clothes-styles')); ?>",
             columns: [
                      {data:  'select',name:'select' },
                      { data: 'name_piecies', name: 'name_piecies' },
                      { data: 'category', name: 'category' },
                      { data: 'count_piecies_handle', name: 'count_piecies_handle' },
                      { data: 'full_price_handle', name: 'full_price_handle' },
                      { data: 'created_at', name: 'created_at' },
                      { data: 'process', name: 'process' },
                      { data: 'show', name: 'show' }
                   ]
          });
     });
    </script>
    <script>
      var typeAlert = "";
      $('.delete').click(function(event){
          typeAlert = null;
          event.preventDefault();

      });
      $('body').on('click','.delete_single',function(event){
        typeAlert = jQuery(this).attr('href');
        event.preventDefault();
      });
      $('body').on('click','.delete_all',function(event){
          typeAlert = jQuery(this).attr('href');
          event.preventDefault();
      });
      $('#confirm_delete').click(function(){
        if(!typeAlert){
          $('form#form_delete_select').submit();        
        }
        else
        {
          window.location.href=typeAlert;
        }
      });
    </script>
    <script >
        jQuery('.printDiv').click(function(event){

            event.preventDefault();

            var printContents = document.getElementById("merchantsContainer").innerHTML;
                              
             var originalContents = document.body.innerHTML;
             
             document.body.innerHTML = printContents;
             
             window.print();
             
             document.body.innerHTML = originalContents;
             window.location.reload();
        });
            
        
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp\www\mohamed-Reda\clothes\resources\views/admin/inventory/styles.blade.php ENDPATH**/ ?>