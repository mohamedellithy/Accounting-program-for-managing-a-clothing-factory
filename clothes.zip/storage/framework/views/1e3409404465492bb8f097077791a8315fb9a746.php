

<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1> اضافة دائن و مدين </h1>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
    <!-- Main content -->
    
    <section class="content">
      <div class="container-fluid">
          <div class="row">
            <?php if(!empty($single_debit)): ?>
              <?php $__currentLoopData = $single_debit; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $debit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <!-- left column -->
              <div class="col-md-12"> 
                <?php if($message = Session::get('success')): ?>
                  <div class="alert alert-warning alert-dismissible">
                      <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                      <h5><i class="icon fas fa-check"></i> تمت</h5>
                      <?php echo e($message); ?>

                    </div>
                <?php endif; ?>
                <!-- general form elements -->
                <div class="card card-primary">
                  <div class="card-header">
                    <h3 class="card-title">اضافة دائن و مدين</h3>
                  </div>
                  <!-- /.card-header -->
                  <!-- form start -->
                  <form action="<?php echo e(url('update-debit/'.$debit->id)); ?>" role="form" method="POST">
                        <?php echo e(csrf_field()); ?>

                    <div class="card-body">
                      <div class="form-group">
                        <label for="exampleInputEmail1">القسم</label>
                        <select name="debitable_type" id="section-type" class="form-control select2"  placeholder="القسم" >
                             <option value="" <?php echo e(($debit->debitable_type?'':'selected')); ?> >أخر</option>
                             <option value="merchant" <?php echo e(($debit->debitable_type=='merchant'?'selected':'')); ?> >تجار</option>
                             <option value="client" <?php echo e(($debit->debitable_type=='client'?'selected':'')); ?> >عملاء</option>
                             <option value="suppliers" <?php echo e(($debit->debitable_type=='suppliers'?'selected':'')); ?> >مصنع</option>
                        </select>
                      </div>

                      <div class="form-group">
                        <label for="exampleInputEmail1">نوع المديونية</label>
                         <select name="debit_type"  class="form-control select2"  placeholder="القسم" required>
                             <option value="دائن" <?php echo e(($debit->debit_type=='دائن'?'selected':'')); ?>>دائن</option>
                             <option value="مدين" <?php echo e(($debit->debit_type=='مدين'?'selected':'')); ?>>مدين</option>
                             
                        </select>
                      </div>

                       <div class="form-group">
                        <label for="exampleInputEmail1">نوع دفع المديونية</label>
                         <select name="type_payment"  class="form-control select2"  placeholder="القسم" required>
                             <option value="نقدى" <?php echo e(($debit->type_payment=='نقدى'?'selected':'')); ?>>نقدى</option>
                             <option value="دفعات" <?php echo e(($debit->type_payment=='دفعات'?'selected':'')); ?>>دفعات</option>
                             <option value="شيكات" <?php echo e(($debit->type_payment=='شيكات'?'selected':'')); ?>>شيكات</option>
                        </select>
                      </div>

                      <div class="form-group" id="merchant_name"  <?php echo e(($debit->debitable_type!='merchant'?"style=display:none":'')); ?> >
                        <label for="exampleInputEmail1">اسم التجار</label>
                        <select name="debitable_id"   class="form-control select2"  placeholder="القسم" style="display:none" >
                          <?php if(!empty($all_merchants)): ?>
                               <?php $__currentLoopData = $all_merchants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $merchant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                   <option value="<?php echo e($merchant->id); ?>" <?php echo e(($debit->debitable_id==$merchant->id?'selected':'')); ?> > <?php echo e($merchant->merchant_name); ?> </option>
                               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                           <?php endif; ?>
                        </select>
                      </div>

                      <div class="form-group" id="client_name" <?php echo e(($debit->debitable_type!='client'?'style=display:none':'')); ?> >
                        <label for="exampleInputEmail1">اسم العميل</label>
                        <select name="debitable_id"   class="form-control select2"  placeholder="القسم" style="display:none" >
                        <?php if(!empty($all_clients)): ?>
                             <?php $__currentLoopData = $all_clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                 <option value="<?php echo e($client->id); ?>" <?php echo e(($debit->debitable_id==$client->id?'selected':'')); ?>> <?php echo e($client->client_name); ?> </option>
                             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                         <?php endif; ?>
                        </select>
                      </div>
                     
                       <div class="form-group" id="supplier_name" <?php echo e(($debit->debitable_type!='suppliers'?'style=display:none':'')); ?>>
                        <label for="exampleInputEmail1">اسم المصنع</label>
                        <select name="debitable_id"  class="form-control select2"  placeholder="القسم"  >
                         <?php if(!empty($all_suppliers)): ?>
                             <?php $__currentLoopData = $all_suppliers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $suppliers): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                 <option value="<?php echo e($suppliers->id); ?>" <?php echo e(($debit->debitable_id==$suppliers->id?'selected':'')); ?> > <?php echo e($suppliers->supplier_name); ?> </option>
                             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                         <?php endif; ?>
                        </select>
                      </div>

                      <div class="form-group" id="debit_name" <?php echo e(($debit->debitable_type!=null?'style=display:none':'')); ?>>
                        <label for="exampleInputPassword1">اسم الدائن / المدين</label>
                        <input name="debit_name"  type="phone" class="form-control" value="<?php echo e(($debit->debit_name?$debit->debit_name:'')); ?>" id="exampleInputPassword1" placeholder="اسم الدائن / المدين" >
                      </div>

                      <div class="form-group">
                        <label for="exampleInputPassword1">قيمة المبلغ الصلي</label>
                        <input name="debit_value" type="debit_value" class="form-control" value="<?php echo e(($debit->debit_value?$debit->debit_value:'')); ?>" id="exampleInputPassword1" placeholder="قيمة المبلغ" required>
                      </div>

                      <div class="form-group">
                        <label for="exampleInputPassword1">قيمة المبلغ المدفوع</label>
                        <input name="payed_check" type="debit_value" class="form-control" value="<?php echo e(($debit->payed_check?$debit->payed_check:'')); ?>" id="exampleInputPassword1" placeholder="قيمة المبلغ" >
                      </div>
                  
                    </div>
                    <!-- /.card-body -->

                    <div class="card-footer">
                      <button type="submit" class="btn btn-primary"> اضافة دائن و مدين </button>
                    </div>
                  </form>
                </div>
                <!-- /.card -->

            
              </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              <?php endif; ?>
          </div>
      </div>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
     <link rel="stylesheet" href="<?php echo e(asset('vendor/adminlte/plugins/plugins/select2/css/select2.min.css')); ?>">
     <link rel="stylesheet" href="<?php echo e(asset('vendor/adminlte/plugins/plugins/select2-bootstrap4-theme/select2-bootstrap4.min.css')); ?>">

    <!-- Bootstrap 4 RTL -->
     <link rel="stylesheet" href="<?php echo e(asset('vendor/adminlte/dist/css/bootstrap-rtl.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('vendor/adminlte/dist/css/custom.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
  <script src="<?php echo e(asset('vendor/adminlte/plugins/plugins/select2/js/select2.full.min.js')); ?>"></script>
  <script type="text/javascript">
         $('.select2').select2({
          theme: 'bootstrap4'
        });

         $('.select3').select2({
          theme: 'bootstrap4'
        });
  </script>
  <script type="text/javascript">
  jQuery('#section-type').change(function(){
     var type_section = jQuery(this).val();
     console.log(type_section);
     if(type_section=="merchant"){
        jQuery('#merchant_name').show();
        jQuery('#supplier_name').hide();
        jQuery('#client_name').hide();
        jQuery('#debit_name').hide();
     }
     else if(type_section=='client'){
        jQuery('#merchant_name').hide();
        jQuery('#supplier_name').hide();
        jQuery('#client_name').show();
        jQuery('#debit_name').hide();
     }
     else if(type_section==''){
        jQuery('#merchant_name').hide();
        jQuery('#supplier_name').hide();
        jQuery('#client_name').hide();
        jQuery('#debit_name').show();
     }
     else if(type_section=='suppliers'){
        jQuery('#merchant_name').hide();
        jQuery('#supplier_name').show();
        jQuery('#client_name').hide();
        jQuery('#debit_name').hide();  
     }
  });
  </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp\www\mohamed-Reda\clothes\resources\views/admin/debit/edite.blade.php ENDPATH**/ ?>