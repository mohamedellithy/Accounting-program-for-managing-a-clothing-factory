<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class expances extends Model
{
    //

    protected $fillable=[
       'expances_value','expances_description',
    ];
}
