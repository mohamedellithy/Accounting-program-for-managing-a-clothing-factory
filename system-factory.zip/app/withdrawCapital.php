<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class withdrawCapital extends Model
{
    //
    protected $fillable = [
      'withdraw_capital','withdraw_profit',
    ];
}
